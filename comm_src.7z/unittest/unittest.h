#ifndef UNIT_TEST_H_
#define UNIT_TEST_H_

namespace unittest{
	void run_test(unsigned int count=10000);
}

#endif
